package projecttwo;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;

//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class QuestionFour {

        public static class MapForWordCount extends Mapper<LongWritable, Text, Text, Text> {

                public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException {

                        String line= value.toString();
                String[] words=line.split("\\s+");

                
                
                String s=words[1];
//                String t  = s.charAt(0) + s.charAt(1) + s.charAt(2) + s.charAt(3) + "-" + s.charAt(4) + s.charAt(5) + "-" + s.charAt(6) + s.charAt(7);
                String max=words[5];
                String min=words[6];
                con.write(new Text(s),new Text(max+"\t"+min));
                }

        }

        public static class ReduceForWordCount extends Reducer<Text, Text, Text, Text> {

                public void reduce(Text lines, Iterator<Text> values, Context con) throws IOException, InterruptedException {


                        String output=values.next().toString();
                        con.write(lines, new Text(output));

                }

        }


        public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
                Configuration c = new Configuration();
                Job j = Job.getInstance(c, "Count");
                j.setJarByClass(QuestionFour.class);
                j.setMapperClass(MapForWordCount.class);
                j.setReducerClass(ReduceForWordCount.class);
                j.setOutputKeyClass(Text.class);
                j.setOutputValueClass(Text.class);
                FileInputFormat.addInputPath(j, new Path(args[0]));
                FileOutputFormat.setOutputPath(j, new Path(args[1]));
                System.exit(j.waitForCompletion(true)?0:1);
        }

}
