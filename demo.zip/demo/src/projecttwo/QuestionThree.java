package projecttwo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class QuestionThree {
	
	 
	
	public static class MapForWordCount extends Mapper<LongWritable, Text, Text, FloatWritable> {
		
		Map<Text, FloatWritable> hashMapColdest;
		Map<Text, FloatWritable> hashMapHottest;
		
		public void setup(Context con) {
			hashMapColdest = new HashMap<Text, FloatWritable>();
			hashMapHottest = new HashMap<Text, FloatWritable>();
		}
			
		public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException {
	
			String row = value.toString();
			String date = row.substring(6,14).replaceAll(" ", "");
			float minTemp = Float.parseFloat(row.substring(46, 53).replaceAll(" ", ""));
			float maxTemp = Float.parseFloat(row.substring(38, 45).replaceAll(" ",""));
			
			
			if (hashMapHottest.keySet().size() < 10) {
				hashMapHottest.put(new Text(date), new FloatWritable(maxTemp));
			} else {
				for (Map.Entry<Text, FloatWritable> entry: hashMapHottest.entrySet()) {
					if (entry.getValue().get() < maxTemp) {
						hashMapHottest.remove(entry.getKey());
						hashMapHottest.put(new Text(date), new FloatWritable(maxTemp));
						break;
					}
				}
			}
			
			if (minTemp == -9999.0) return;
			if (hashMapColdest.keySet().size() < 10) {
				hashMapColdest.put(new Text(date), new FloatWritable(minTemp));
			} else {
				for (Map.Entry<Text, FloatWritable> entry: hashMapColdest.entrySet()) {
					if (entry.getValue().get() > minTemp) {
						hashMapColdest.remove(entry.getKey());
						hashMapColdest.put(new Text(date), new FloatWritable(minTemp));
						break;
					}
				}
			}
			
		}
		
		public void cleanup(Context con) throws IOException, InterruptedException {
//			con.write(new Text("Hottest days :"), new FloatWritable(0));
			for (Map.Entry<Text, FloatWritable> entry: hashMapHottest.entrySet()) {
				con.write(new Text("Hottest " + entry.getKey()), entry.getValue());
			}
			
//			con.write(new Text("Coldest days :"), new FloatWritable(0));
			for (Map.Entry<Text, FloatWritable> entry: hashMapColdest.entrySet()) {
				con.write(new Text("Coldest " + entry.getKey()), entry.getValue());
			}
		}
	}
	
	public static class ReduceForWordCount extends Reducer<Text, FloatWritable, Text, FloatWritable> {
	
		public void reduce(Text word, Iterable<FloatWritable> values, Context con) throws IOException, InterruptedException {
			for (FloatWritable value: values) {
				con.write(new Text(word), value);
			}
		}
	}
	
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Configuration c = new Configuration();
		Job j = Job.getInstance(c, "wordcount");
		
		j.setJarByClass(QuestionThree.class);
		j.setMapperClass(MapForWordCount.class);
		j.setReducerClass(ReduceForWordCount.class);
		j.setOutputKeyClass(Text.class);
		j.setOutputValueClass(FloatWritable.class);
		
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path(args[1]));
		System.exit(j.waitForCompletion(true)?0:1);
	}

}
